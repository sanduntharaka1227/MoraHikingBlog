# Mora Hiking Blog 🌲
**Community Blog Web Application for the University of Moratuwa Hiking Club**

A full-stack, nature-inspired community blogging platform where members and outdoor enthusiasts of the **University of Moratuwa Hiking Club (Mora Hiking Club)** can register, sign in, and share rich Markdown-formatted expedition reports, trail guides, and wilderness camping stories.

---

## 🌟 Key Features

1. **Nature-Inspired Glassmorphic Design**:
   - Palette: Forest Green (`#2E5339`), Moss Green (`#4A7856`), Sage (`#8AA68C`), Earth Sand (`#D8C3A5`), Sky Blue (`#7FB3D5`), and Sunlight Yellow (`#E8C468`).
   - Glassmorphism aesthetic with soft translucent cards (`rgba(255, 255, 255, 0.85)`), `backdrop-filter: blur(14px)`, and `20px–24px` rounded corners.
   - Low-opacity scenic hiking sunset background showing through behind the content.
   - Paired official branding: University of Moratuwa logo & Mora Hiking Club round badge in the navigation bar and hero banner.
   - Fully responsive layout for smartphones, tablets, and desktop displays.

2. **User Authentication & Authorization**:
   - Secure registration, login, and logout.
   - Password hashing using PHP `password_hash()` and `password_verify()`.
   - Role-based permissions (`member` and `admin`).
   - Server-side authorization verification ensuring users can only edit or delete their own posts (while admins can moderate any post).

3. **Markdown Trail Story Editor & Renderer**:
   - Modern **EasyMDE** Markdown Editor via CDN for drafting reports with headers, checklists, quotes, and images.
   - Server-side Markdown parsing via **Parsedown** with **Safe Mode** enabled for XSS defense.
   - Instant live search & filter on the homepage.

4. **Security Hardening**:
   - Prepared statements via **PDO** for all database queries (protection against SQL Injection).
   - HTML output sanitization (`htmlspecialchars`).
   - CSRF protection token verification on all POST operations.
   - Session fixation protection via `session_regenerate_id(true)`.

---

## 📁 Project Structure

```
mora-hiking-blog/
├── assets/
│   ├── css/
│   │   └── style.css            # Nature-themed styles, glassmorphism, responsive grid
│   ├── js/
│   │   └── main.js              # Navbar toggle, delete modal, live search, alert dismissals
│   └── images/
│       ├── uni-logo.png         # University of Moratuwa Official Crest
│       ├── uom-logo.png         # Crest alias
│       ├── mora-hiking-logo.png # Mora Hiking Club Emblem
│       ├── hiking-club-logo.png # Emblem alias
│       ├── background.jpg       # Low-opacity mountain sunset background
│       └── hero-bg.jpg          # Background alias
├── includes/
│   ├── db.php                   # Database connection (PDO) with auto-creation fallback
│   ├── auth.php                 # Auth functions, session management, CSRF & helper utilities
│   ├── Parsedown.php            # Standalone PHP Markdown parser with XSS Safe Mode
│   ├── header.php               # Dual-logo header, fonts, icons, navigation bar
│   └── footer.php               # Nature footer, quick links, delete confirmation modal
├── sql/
│   └── schema.sql               # MySQL database schema and initial seed data
├── index.php                    # Homepage with hero banner and blog post cards
├── view_post.php                # Single post view with rendered Markdown
├── create_post.php              # Create post page with EasyMDE editor
├── edit_post.php                # Edit post page with pre-filled markdown
├── delete_post.php              # Delete post script with authorization verification
├── login.php                    # Member login page
├── register.php                 # Member registration page
├── logout.php                   # Secure session termination
└── README.md                    # Project documentation
```

---

## 🚀 How to Run on XAMPP (Local Environment)

### Step 1: Place the Project in XAMPP
Copy the `mora-hiking-blog` directory into your XAMPP `htdocs` directory:
```
C:\xampp\htdocs\mora-hiking-blog
```

### Step 2: Start Apache and MySQL
1. Open the **XAMPP Control Panel**.
2. Click **Start** for **Apache**.
3. Click **Start** for **MySQL**.

### Step 3: Import the Database
1. Open your browser and go to `http://localhost/phpmyadmin/`.
2. Click on the **Import** tab.
3. Choose the file located at:
   `C:\xampp\htdocs\mora-hiking-blog\sql\schema.sql`
4. Click **Go** (or **Import** at the bottom).

*(Note: `includes/db.php` is also designed to automatically create the database `mora_hiking_blog` and seed the tables if accessed directly when MySQL is running!)*

### Step 4: Open the Web Application
Navigate to the following URL in your web browser:
```
http://localhost/mora-hiking-blog/
```

---

## 🔑 Default Test Credentials

The database comes pre-seeded with sample members and trail reports:

| Role | Username | Email | Password |
| :--- | :--- | :--- | :--- |
| **Club Admin** | `mora_admin` | `admin@hiking.mrt.ac.lk` | `Password@123` |
| **Member** | `chathura_k` | `chathura@mora.ac.lk` | `Password@123` |
| **Member** | `rashmi_w` | `rashmi@mora.ac.lk` | `Password@123` |

*You can also register a new account on `register.php` anytime.*

---

## 🌐 Deploying to Live Web Hosting (e.g. InfinityFree / 000WebHost)

1. **Upload Files**: Upload the contents of `mora-hiking-blog` to the `htdocs` or `public_html` directory of your hosting provider via FTP or File Manager.
2. **Create MySQL Database**: In your hosting cPanel, create a new MySQL database and user.
3. **Import SQL**: Open phpMyAdmin on your hosting control panel and import `sql/schema.sql`.
4. **Update Credentials**: Open `includes/db.php` on the server and update `DB_HOST`, `DB_NAME`, `DB_USER`, and `DB_PASS` to match your hosting database details.
